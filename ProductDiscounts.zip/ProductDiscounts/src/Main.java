/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author GHOST
 */
public class Main {
    public static void main(String[] args) {
        // Create an array of products
        Product[] products = {
            new Clothing("T-Shirt", 20.0),
            new Electronics("Smartphone", 500.0),
            new Clothing("Jeans", 40.0),
            new Electronics("Laptop", 1000.0)
        };

        // Loop through products and print discounted prices
        for (Product product : products) {
            System.out.println(product.getName() + " - Discounted Price: R" + product.getDiscountedPrice());
        }
    }
}
